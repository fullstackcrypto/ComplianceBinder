const API = '';
let token = localStorage.getItem('cb_token') || '';
let currentBinderId = null;
let currentEmail = localStorage.getItem('cb_email') || '';

function setMsg(el, msg, isError=false) {
  el.textContent = msg;
  el.style.color = isError ? 'var(--danger)' : 'var(--muted)';
}

function authHeaders() {
  return { Authorization: `Bearer ${token}` };
}

async function apiFetch(path, options = {}) {
  const res = await fetch(API + path, options);
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(txt || res.statusText);
  }
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) return res.json();
  return res.text();
}

function showApp() {
  document.getElementById('auth').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
  document.getElementById('who').textContent = currentEmail;
}

function showAuth() {
  document.getElementById('auth').classList.remove('hidden');
  document.getElementById('app').classList.add('hidden');
}

async function register() {
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const msg = document.getElementById('authMsg');
  if (!email || !password) return setMsg(msg, 'Enter email and password', true);
  try {
    await apiFetch('/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    setMsg(msg, 'Registered. Now click Login.');
  } catch (e) {
    setMsg(msg, e.message, true);
  }
}

async function login() {
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const msg = document.getElementById('authMsg');
  if (!email || !password) return setMsg(msg, 'Enter email and password', true);

  const form = new URLSearchParams();
  form.append('username', email);
  form.append('password', password);

  try {
    const data = await apiFetch('/auth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form
    });
    token = data.access_token;
    currentEmail = email;
    localStorage.setItem('cb_token', token);
    localStorage.setItem('cb_email', currentEmail);
    showApp();
    await refreshBinders();
  } catch (e) {
    setMsg(msg, 'Login failed', true);
  }
}

async function refreshBinders() {
  const list = document.getElementById('binderList');
  list.innerHTML = '';
  const binders = await apiFetch('/binders', { headers: authHeaders() });
  binders.forEach(b => {
    const li = document.createElement('li');
    li.innerHTML = `<div><strong>${b.name}</strong> <span class="meta">(${b.industry})</span></div>`;
    li.style.cursor = 'pointer';
    li.onclick = () => selectBinder(b.id, b.name);
    list.appendChild(li);
  });
}

async function createBinder() {
  const name = document.getElementById('binderName').value.trim();
  const industry = document.getElementById('binderIndustry').value;
  if (!name) return;
  await apiFetch('/binders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ name, industry })
  });
  document.getElementById('binderName').value = '';
  await refreshBinders();
}

async function selectBinder(id, name) {
  currentBinderId = id;
  document.getElementById('binderTitle').textContent = name;
  document.getElementById('binderActions').classList.remove('hidden');
  document.getElementById('reportLink').href = `/binders/${id}/report?token=${encodeURIComponent(token)}`;

  // The report endpoint uses Authorization; link won't include it.
  // We'll open it via fetch+blob in a new tab instead.
  document.getElementById('reportLink').onclick = async (e) => {
    e.preventDefault();
    const html = await apiFetch(`/binders/${id}/report`, { headers: authHeaders() });
    const w = window.open('', '_blank');
    w.document.open();
    w.document.write(html);
    w.document.close();
  };

  await refreshTasks();
  await refreshDocs();
}

async function refreshTasks() {
  const list = document.getElementById('taskList');
  list.innerHTML = '';
  const tasks = await apiFetch(`/binders/${currentBinderId}/tasks`, { headers: authHeaders() });
  tasks.forEach(t => {
    const li = document.createElement('li');
    const due = t.due_date ? `Due: ${t.due_date}` : '';
    const status = t.status === 'done' ? '✅' : '⬜';
    li.innerHTML = `
      <div><strong>${status} ${t.title}</strong> <span class="meta">${due}</span></div>
      <div class="meta">${t.description || ''}</div>
    `;
    if (t.status !== 'done') {
      const btn = document.createElement('button');
      btn.textContent = 'Mark done';
      btn.className = 'secondary';
      btn.onclick = async () => {
        await apiFetch(`/tasks/${t.id}/done`, { method: 'POST', headers: authHeaders() });
        await refreshTasks();
      };
      li.appendChild(btn);
    }
    list.appendChild(li);
  });
}

async function addTask() {
  const title = document.getElementById('taskTitle').value.trim();
  const description = document.getElementById('taskDesc').value.trim();
  const due_date = document.getElementById('taskDue').value || null;
  if (!title) return;

  await apiFetch(`/binders/${currentBinderId}/tasks`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ title, description, due_date })
  });

  document.getElementById('taskTitle').value = '';
  document.getElementById('taskDesc').value = '';
  document.getElementById('taskDue').value = '';
  await refreshTasks();
}

async function refreshDocs() {
  const list = document.getElementById('docList');
  list.innerHTML = '';
  const docs = await apiFetch(`/binders/${currentBinderId}/documents`, { headers: authHeaders() });
  docs.forEach(d => {
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = '#';
    a.textContent = d.original_name;
    a.onclick = async (e) => {
      e.preventDefault();
      // download via authenticated fetch
      const res = await fetch(`/documents/${d.id}/download`, { headers: authHeaders() });
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const tmp = document.createElement('a');
      tmp.href = url;
      tmp.download = d.original_name;
      tmp.click();
      URL.revokeObjectURL(url);
    };
    li.appendChild(a);
    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.textContent = d.note || '';
    li.appendChild(meta);
    list.appendChild(li);
  });
}

async function uploadDoc() {
  const file = document.getElementById('docFile').files[0];
  const note = document.getElementById('docNote').value.trim();
  if (!file) return;
  const fd = new FormData();
  fd.append('file', file);
  fd.append('note', note);

  await apiFetch(`/binders/${currentBinderId}/documents`, {
    method: 'POST',
    headers: authHeaders(),
    body: fd
  });

  document.getElementById('docFile').value = '';
  document.getElementById('docNote').value = '';
  await refreshDocs();
}

function logout() {
  token = '';
  currentBinderId = null;
  localStorage.removeItem('cb_token');
  localStorage.removeItem('cb_email');
  showAuth();
}

document.getElementById('loginBtn').onclick = login;
document.getElementById('registerBtn').onclick = register;
document.getElementById('createBinderBtn').onclick = createBinder;
document.getElementById('addTaskBtn').onclick = addTask;
document.getElementById('uploadDocBtn').onclick = uploadDoc;
document.getElementById('logoutBtn').onclick = logout;

// Auto-login if token stored
if (token) {
  showApp();
  refreshBinders().catch(() => logout());
}
